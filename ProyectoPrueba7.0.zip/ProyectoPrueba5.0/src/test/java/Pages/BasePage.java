package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.sql.Driver;
import java.time.Duration;

public class BasePage {
    protected static WebDriver driver;
    private static WebDriverWait wait2;
    private Actions action;

    static {
        System.setProperty("webdriver.chrome.driver",
                "C:\\Users\\Ronal\\IdeaProjects\\ProyectoPrueba\\chromedriver.exe");
        ChromeOptions options = new ChromeOptions();
        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        wait2 = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
    public BasePage(WebDriver driver) {
        BasePage.driver = driver;
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(35));
    }
    public static void closeBrowser() {
        driver.quit();
    }
    //navegar a una pagina:
    public static void navegarA(String url) {
        driver.get(url);
    }
    private static WebElement findByXpath(String locator) {
        return wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator)));
    }
    //Click en un elemento
    public void clickElement(String locator) {
        findByXpath(locator).click();
    }
    //Escribir
    public void write(String locator, String textToWrite) {
        findByXpath(locator).clear();
        findByXpath(locator).sendKeys(textToWrite);
    }
    //Obtener Texto
    public String obtenerTexto(String locator) {return findByXpath(locator).getText();}

    //Sirve para pasar el cursor sobre el elemento
    public void moveToElement(String locator){action.moveToElement(findByXpath(locator)).click();}

    //-----------------validaciones
    public boolean isDisplayed(String locator) {return findByXpath(locator).isDisplayed();}

    public boolean isEnabled(String locator){
        return findByXpath(locator).isEnabled();
    }
    //----------------------------------------------------------
    public void switchToWindowsElement(int index) {
        driver.switchTo().frame(index);
    }

    public void switchToDefaultContent() {
        driver.switchTo().defaultContent();
    }
    public void switchToParentFrame() {
        driver.switchTo().parentFrame();
    }

}