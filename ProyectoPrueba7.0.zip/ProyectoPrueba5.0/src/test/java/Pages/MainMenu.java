package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class MainMenu extends BasePage {
    public MainMenu() {
        super(driver);
    }

    //Locators Main Menu
    private String campoBusqueda = "//*[@id='search_query_top']";
    private String botonBuscar = "//header/div[3]/div[1]/div[1]/div[2]/form[1]/button[1]";
    private String signIn = "//a[contains(text(),'Sign in')]";

    //METODOS (Acciones) Main Menu

    public void navegarAutomationPractice() throws InterruptedException {
        navegarA("http://automationpractice.com/index.php");
    }
    public void clicEnBarraBusqueda() {
        clickElement(campoBusqueda);
    }
    public void clicEnBusqueda() throws InterruptedException {
        clickElement(botonBuscar);
        Thread.sleep(400);
    }
    public void escribirNombreDeProducto(String texto) {
        write(campoBusqueda, texto);
    }
    public void clicEnSignIn() throws InterruptedException {
       Thread.sleep(400);
        clickElement(signIn);
    }
    public void clicEnBoton(String locator)  {

        clickElement(locator);
    }
    public void switchToProduct(int index){
        switchToWindowsElement(index);
}

}
