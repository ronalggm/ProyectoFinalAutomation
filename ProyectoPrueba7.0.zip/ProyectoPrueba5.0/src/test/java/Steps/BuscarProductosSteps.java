package Steps;

import Pages.MainMenu;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.awaitility.Awaitility;
import org.junit.Assert;

import java.util.concurrent.TimeUnit;

public class BuscarProductosSteps {

    //-----------Objetos
    MainMenu mainMenu = new MainMenu();
    //-------------------Locators Validaciones
    private String cantidadBusqueda = "//span[@class='heading-counter']";
    private String nombeProducto = "//*[@id=\"center_column\"]/h1/span[1]";
    private String productoNoEncontrado = "//p[@class='alert alert-warning']";

    private String printedSummerDress = "//a[@data-id-product='5']/span[1]";
    private String printedChifonDressIMG = "//img[@alt=\"Printed Chiffon Dress\"]";
    private String addToCart = "//span[contains(text(),'Add to cart')]";

    //-------------------------------------------------------------------------
    @Given("Ingreso a la pagina web AutomationPractice")
    public void ingresoALaPaginaWebAutomationPractice() throws InterruptedException {
        mainMenu.navegarAutomationPractice();
    }

    @When("Escribo nombre de un producto {string}")
    public void escriboNombreDeUnProductoProducto(String producto) {
        mainMenu.escribirNombreDeProducto(producto);
    }

    @And("Doy clic en el boton de busqueda")
    public void doyClicEnElBotonDeBusqueda() throws InterruptedException {
        Thread.sleep(600);
        mainMenu.clicEnBusqueda();
    }
    @Then("Valido que aparezca {int} de elementos encontrado")
    public void ValidoCantidad(int cantidad) {

        String elementos = mainMenu.obtenerTexto(cantidadBusqueda);
        System.out.println("Resultado cantidad: " + elementos);
        String PrimerCaracter = String.valueOf(elementos.charAt(0));

        if (PrimerCaracter.contains("0")) {
            System.out.println("No se encontraron articulos");
            System.out.println("Mensaje: " + mainMenu.obtenerTexto(productoNoEncontrado));
        }
        int result = Integer.parseInt(PrimerCaracter);
        Assert.assertEquals("No se encontro elemento", result, cantidad);
    }
    @And("Valido que aparezca el nombre {string} en la pag")
    public void validoQueAparezcaElNombreNombreEnLaPag(String result) {
        String resulBusqueda = mainMenu.obtenerTexto(nombeProducto).replace("\"", "");
        if (resulBusqueda.contains("0")) {
            resulBusqueda = "";
        }
        System.out.println("Resultado espeado: " + result);
        System.out.println("Resultado obtenido: " + resulBusqueda);
        Assert.assertEquals("No se encontro elemento", result, resulBusqueda);
    }

    @And("Agrego un producto al carrito")
    public void agregoUnProductoAlCarrito() throws InterruptedException {
mainMenu.clicEnBoton(printedChifonDressIMG);
        mainMenu.switchToProduct(0);
        mainMenu.clicEnBoton(addToCart);
        Thread.sleep(500);

    }

}





