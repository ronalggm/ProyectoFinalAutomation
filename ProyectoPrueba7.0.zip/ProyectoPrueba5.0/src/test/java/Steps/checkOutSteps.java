package Steps;

import Pages.CheckOut;
import com.beust.ah.A;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.Assert;

public class checkOutSteps {

    //Objetos
    CheckOut chekOut = new CheckOut();
    //locators validaciones
    private String validationForCheck = "//p[contains(text(), 'Your order on My Store is complete.')]";
    private String validationForWire = "//*[@id='center_column']/div/p/strong";
    int camino;
    @And("Realizo el checkout con Pay by check")
    public int realizoElCheckout() throws InterruptedException {
        camino = 1;
        Thread.sleep(900);
        // chekOut.switchToProduct(0);
        chekOut.switchToMain();
        chekOut.clicProceedToCheckout1();
        chekOut.clicProceedToCheckout2();
        chekOut.clicProceedToCheckout3();
        chekOut.clicTermsAndConditions();
        chekOut.clicProceedToCheckout4();
        chekOut.clicOnPayByCheck();
        chekOut.clicOnIConfirmMyOrderCheque();
        return camino;
    }
    @And("Realizo el checkout con Transferencia bancaria")
    public int realizoElCheckoutConTransferenciaBancaria() throws InterruptedException {
        camino = 2;
        chekOut.switchToMain();
        chekOut.clicProceedToCheckout1();
        chekOut.clicProceedToCheckout2();
        chekOut.clicProceedToCheckout3();
        chekOut.clicTermsAndConditions();
        chekOut.clicProceedToCheckout4();
        chekOut.clicOnPayByWire();
        chekOut.clicProceedToCheckoutwire();

        return camino;
    }
    @Then("Confirmo que la compra fue exitosa")
    public void confirmoQueLaCompraFueExitosa() {
        boolean result;
        if (camino == 1) {
            result = chekOut.yourOrderisCompleted(validationForCheck);
            Assert.assertTrue("La compra no fue Exitosa", result);
        } else if (camino == 2) {
            result = chekOut.yourOrderisCompleted(validationForWire);
            Assert.assertTrue("La compra no fue exitosa", result);
        }
    }

}
